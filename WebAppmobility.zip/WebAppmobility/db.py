import mysql.connector

def connect_to_database():
  return mysql.connector.connect(
    host="mobility-web-app-db-mobility-web-app.a.aivencloud.com",
    user="avnadmin",
    password="AVNS_80ms1tmZWNDTeIqDfmp",
    database="stretchexercisedb", 
port="21962"
  )

def list_grupper(tab_name):
  mydb = connect_to_database()
  cursor = mydb.cursor()
  table_name = tab_name

  query = f"SHOW columns FROM {table_name};"

  cursor.execute(query)

  columns_info = cursor.fetchall()

  column_names = [column_info[0] for column_info in columns_info]
  
#  column_names = [column_info[0] for column_info in columns_info]

  column_names.pop(0)
  column_names.pop(0)

  cursor.close()  # Close the cursor
  mydb.close()    # Close the connection
  
  return column_names
  

def grab_user_choices(muscle_choices, eqp_choices):
  mydb = connect_to_database()

  cursor = mydb.cursor()

  query = "SELECT * FROM exercises_data WHERE ({}) AND {};".format(muscle_choices, eqp_choices)

  print(f'Query: {query}\n\n')

  cursor.execute(query)

  myresult = cursor.fetchall()
  print(f'Myresult: {myresult[2]}\n\nType of Myresult: {type(myresult[2])}\n\n')

  # Get column names
  columns = [col[0] for col in cursor.description]

  result_dict_list = []
  # Loop through each tuple in the list
  for result in myresult:
      result_dict = {}
      # Pair column names with values
      for col, value in zip(columns, result):
          result_dict[col] = value
      result_dict_list.append(result_dict)

  cursor.close()  # Close the cursor
  mydb.close()    # Close the connection

  print(f'result_dict_list: {result_dict_list}')
  return result_dict_list
  

def negative_udstyr_list():
  # Connect to your MySQL database
  mydb = connect_to_database()
  
  # Create a cursor object
  cursor = mydb.cursor()
  
  # Specify the table name
  table_name = "exercises_data"
  
  # Fetch the column names that start with "udstyr_" from the specified table
  cursor.execute(f"SHOW COLUMNS FROM {table_name} LIKE 'udstyr_%'")
  udstyr_columns = [column[0] for column in cursor.fetchall()]
  
  # Close the cursor and connection
  cursor.close()
  mydb.close()
  
  # Print or use the list of "udstyr_" columns
  return udstyr_columns