import mysql.connector
import random
from vaelg_grupper import valg_grupper

mydb = mysql.connector.connect(
  host="aws.connect.psdb.cloud",
  user="4cziltkl862d3t1smt3s",
  password="pscale_pw_LstZfyTE5zFVeRgORS2pYpfVVIfROtf5gLUkji1Y2qC",
  database="stretchexercisedb"
)

#Liste for at teste Len()
groups_liste = []
udstyr_liste = []

# START - FUNKTION DER OPRETTER MED USER INPUTS FOR MUSKELGRUPPER OG UDSTYR
def get_dynamic_inputs(prompt_text, yes_no_text):
    input_list = []
    yes_no = "yes"

    while yes_no.lower() == "yes":
        user_input = input(prompt_text)
        input_list.append(user_input)
        yes_no = input(yes_no_text)

    return input_list
# SLUT #

# START - BRUGERINPUTS TAGES HER, FØRST FOR MUSKELGRUPPER, DERNÆST FOR UDSTYR

muskel_prompt = "Vælg muskelgruppe du vil træne fra listen ovenfor (tast 0 for exit): "
muskel_db = "grupper"

groups_liste = valg_grupper(muskel_db, muskel_prompt)

print(len(groups_liste))
print(f'groups_liste: {groups_liste}')

if groups_liste[0] == "":
    groups_liste = ['hips_gruppe', 'ankles_gruppe', 'overhead_gruppe', 'shoulders_gruppe', 'postchain_gruppe']
    or_and_groups = "OR"
elif len(groups_liste) > 1:
    or_and_groups = input("OR / AND: ")
else:
    or_and_groups = "OR"

# HER FOR UDSTYR

udstyr_prompt = "Vælg udstyr fra listen du vil bruge i din træning (tast 0 for exit): "
udstyr_db = "udstyr"

udstyrs_liste = valg_grupper(udstyr_db, udstyr_prompt)

input_duration = int(input("Hvor lang tid vil du strække ud? "))
# SLUT #

# SLUT MED AT BYGGE BRUGERLISTER

# START - OPRETTELSE AF STR DER SÆTTES IND I SQL QUERY MED MUSKELGRUPPE(R) DER SKAL STRÆKKES
def generate_user_choices(choice_list, seperator1, seperator2):
    user_choices = ""

    count_test = len(choice_list) - 1
    for x in choice_list:
        user_choices = user_choices + x + seperator1
        if count_test > 0:
            user_choices = user_choices + seperator2
            count_test -= 1

    return user_choices

# SLUT #

musclegroup_choices = generate_user_choices(groups_liste, " > 0 ", f'{or_and_groups.upper()} ')
udstyr_choices = generate_user_choices(udstyrs_liste, " = 1 ", "OR ")

cursor = mydb.cursor()

query = "SELECT exercise_name FROM exercises_data WHERE " + musclegroup_choices + "AND (" + udstyr_choices + ");"

cursor.execute(query)

myresult = cursor.fetchall()

# REFORMAT CREATED LIST OF EXERCISES
myresult_formatted = [key[0] for key in myresult]

# START - TIDSFUNKTIONEN #
loop_duration = input_duration

exercise_list = []

while loop_duration > 0:
    ran_duration = random.choice([1, 2, 3])
    exercise_list.append(ran_duration)
    loop_duration = loop_duration - ran_duration

if sum(exercise_list) > input_duration:
    int_remove = sum(exercise_list) - input_duration
    exercise_list.remove(int_remove)
# SLUT - TIDSFUNKTIONEN #


# START - MIX TIDSFUNKTIONEN MED LISTE OVER ØVELSER #
dict_exercise = {}

for x in exercise_list:
  ran_choice = random.choice(myresult_formatted)
  dict_exercise.update({ran_choice:x})


for x, v in dict_exercise.items():
    print(f'Udfør {x} i {v} minut(ter)')
# SLUT - MIX TIDSFUNKTIONEN MED LISTE OVER ØVELSER #