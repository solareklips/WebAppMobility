import json
import random

from flask import Flask, redirect, render_template, request, url_for

from db import grab_user_choices, list_grupper, negative_udstyr_list

app = Flask(__name__)


@app.route("/", methods=["POST", "GET"])
def list_choices():
  muscle_groups = list_grupper("grupper")
  equipment = list_grupper("udstyr")

  if request.method == "POST":
    uw = request.form.getlist('user_workout')
    uq = request.form.getlist('user_equipment')
    ud = request.form.getlist('user_duration')

    uw_uq = {"user_muscles": uw, "user_equipment": uq, "user_duration": ud}
    uw2_str = json.dumps(uw_uq)
    print(
        f'Data collected:\n{uw_uq["user_muscles"]}\n{uw_uq["user_equipment"]}\n{uw_uq["user_duration"]}...{uw_uq}'
    )
    return redirect(url_for("uw_uq", uw2=uw2_str))
  else:
    return render_template('home.html',
                           muscle_groups=muscle_groups,
                           equipment=equipment)


@app.route("/<uw2>")
def uw_uq(uw2):
  try:
    uw2_dict = json.loads(uw2) if uw2 else {}
    user_muscles_list = uw2_dict["user_muscles"]
    user_equipment_list = uw2_dict["user_equipment"]
    user_duration_list = uw2_dict["user_duration"]

    for duration in user_duration_list:
      duration = int(duration)
      print(f'Duration int: {duration} {type(duration)}\n\n')

    # Dannelse af negativ udstyrsliste, så brugeren ikke får udstyr der kræver to stk. udstyr
    full_equipment_list = negative_udstyr_list()
    print(f'Full equipment list: {full_equipment_list}\n\n')

    negative_list = [
        col for col in full_equipment_list if col not in user_equipment_list
    ]
    print(f'Negative list: {negative_list}\n\n')

    # Assume positive_list and negative_list are lists with column names

    # Create a dictionary with all columns initialized to 0
    column_values = {
        column: 0
        for column in set(user_equipment_list + negative_list)
    }

    # Set the values to 1 for the columns in the positive list
    for column in user_equipment_list:
      column_values[column] = 1

    print(f'Column values: {column_values}')

    # Now column_values is a dictionary with 1 for positive columns and 0 for negative columns
    print(f'Column values: {column_values}\n\n')

    def generate_user_equipment(choice_dict, seperator1, seperator2):
      user_choices = ""

      count_test = len(choice_dict) - 1
      for column, value in choice_dict.items():
        if value == 1:
          user_choices = user_choices + column + seperator1
          if count_test > 0:
            user_choices = user_choices + seperator2
            count_test -= 1
      print(f'User choices: {user_choices}\n\n')
      return user_choices

  # START - OPRETTELSE AF STR DER SÆTTES IND I SQL QUERY MED MUSKELGRUPPE(R) DER SKAL STRÆKKES

    def generate_user_choices(choice_list, seperator1, seperator2):
      user_choices = ""

      count_test = len(choice_list) - 1
      for x in choice_list:
        user_choices = user_choices + x + seperator1
        if count_test > 0:
          user_choices = user_choices + seperator2
          count_test -= 1
      print(f'User choices: {user_choices}\n\n')
      return user_choices
  # SLUT

    musclegroup_choices = generate_user_choices(user_muscles_list, " > 0 ",
                                                "OR ")
    equipment_choices = generate_user_choices(negative_list, " = 0 ", "AND ")
    print(
        f'Musclegroups: {musclegroup_choices}\nEquipment: {equipment_choices}')

    # Få grab_user_choices til at hente alt info om en øvelse og gem det i en dict
    workout = grab_user_choices(musclegroup_choices, equipment_choices)

    # Skriv funktionalitet her
    def create_dict_exercise(workout_dict, total_duration):
      workout_dict_copy = workout_dict[:]
      dict = {}
      duration_secs = total_duration * 60
      loop_duration = duration_secs

      while loop_duration > 0:
        exercise = random.choice(workout_dict_copy)
        if loop_duration == 60:
          exercise = random.choice([
            exercise for exercise in workout_dict_copy
            if exercise["twoside"] == 0
          ])
          duration = 60
          loop_duration -= duration    
          dict[exercise["exercise_name"]] = {"duration": duration, "youtube_id": exercise["yt_id"]}
        elif exercise["twoside"] == 1:
            # Tilføj key-value pairs for højre og venstre side
          dict[f"{exercise['exercise_name']} - right side"] = {"duration": 60, "youtube_id": exercise["yt_id"]}
          dict[f"{exercise['exercise_name']} - left side"] = {"duration": 60, "youtube_id": exercise["yt_id"]}
          loop_duration -= 120
        elif exercise["twoside"] == 0:
          duration = random.choice([60, 120])
          loop_duration -= duration
            # Tilføj øvelsen til dictionary'en med dens varighed
          dict[exercise["exercise_name"]] = {"duration": duration, "youtube_id": exercise["yt_id"]}
        else:
          print("Der opstod en fejl")
        
        workout_dict_copy.remove(exercise)

      return dict


    dict_exercise = create_dict_exercise(workout, duration)

    print(f'dict_exercise: {dict_exercise}')

    for x, v in dict_exercise.items():
      print(f'Udfør {x} i {v} sekunder\n')

    return render_template('workout.html',
                           user_muscles_list=user_muscles_list,
                           user_equipment_list=user_equipment_list,
                           user_duration_list=user_duration_list,
                           duration=duration,
                           dict_exercise=dict_exercise)

  except json.JSONDecodeError:
    return "Invalid data format"


if __name__ == "__main__":
  app.run(host='0.0.0.0', debug=True)

# denne her https://stackoverflow.com/questions/5316720/how-can-i-convert-string-values-from-a-dictionary-into-int-float-datatypes bør kunne convertere duration til int fra string
