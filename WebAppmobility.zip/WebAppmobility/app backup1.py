import mysql.connector
from flask import Flask, render_template, request
#, jsonify, request
#from database import valg_grupper

app = Flask(__name__)

@app.route("/")
def list_grupper():
  mydb = mysql.connector.connect(
    host="aws.connect.psdb.cloud",
    user="4cziltkl862d3t1smt3s",
    password="pscale_pw_LstZfyTE5zFVeRgORS2pYpfVVIfROtf5gLUkji1Y2qC",
    database="stretchexercisedb"
  )

  cursor = mydb.cursor()

  table_name = "grupper"

  query = f"SHOW columns FROM {table_name};"

  cursor.execute(query)

  columns_info = cursor.fetchall()

  column_names = [column_info[0] for column_info in columns_info]

  column_names.pop(0)
  column_names.pop(len(column_names)-1)

  return render_template('home.html',
    column_names=column_names)  


#FÅ DENNE HER FUNKTION TIL AT VIRKE. DEN SKAL SKRIVE BRUGERENS VALG PÅ WORKOUT.HTML
@app.route("/workout/", methods=['POST', 'GET'])
def workout():
  user_workout = request.form.getlist('user_workout')
  print(user_workout)
#  user_workout = request.form.getlist('user_workout')
#  if request.method == 'POST':
#    print(user_workout)
#    return user_workout
#  print(f'1 ', user_workout)
  return render_template('workout.html', 
                         user_workout=user_workout)

if __name__ == "__main__":
  app.run(host='0.0.0.0', debug=True)