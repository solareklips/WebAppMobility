def valg_grupper(tab_name, grupper_prompt):
  import mysql.connector

  mydb = mysql.connector.connect(
    host="aws.connect.psdb.cloud",
    user="4cziltkl862d3t1smt3s",
    password="pscale_pw_LstZfyTE5zFVeRgORS2pYpfVVIfROtf5gLUkji1Y2qC",
    database="stretchexercisedb"
  )

  cursor = mydb.cursor()

  table_name = tab_name

  query = f"SHOW columns FROM {table_name};"

  cursor.execute(query)

  columns_info = cursor.fetchall()

  column_names = [column_info[0] for column_info in columns_info]

  column_names.pop(0)
  column_names.pop(len(column_names)-1)


  count = 1
  gruppe_ids = []
  for gr in column_names:
      print(f'Tast {count} for {gr}')
      gruppe_ids.append(count)
      count = count + 1
  return gruppe_ids