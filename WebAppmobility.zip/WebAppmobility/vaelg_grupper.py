# LAV SÅ BRUGEREN KAN VÆLGE INGENTING, ALTSÅ VÆLGER SÅ AUTOMATISK FRIT FRA ALLE MUSKELGRUPPER OG ALT UDSTYR
def valg_grupper(tab_name, grupper_prompt):
    import mysql.connector

    mydb = mysql.connector.connect(
      host="aws.connect.psdb.cloud",
      user="4cziltkl862d3t1smt3s",
      password="pscale_pw_LstZfyTE5zFVeRgORS2pYpfVVIfROtf5gLUkji1Y2qC",
      database="stretchexercisedb"
    )

    cursor = mydb.cursor()

    table_name = tab_name

    query = f"SHOW columns FROM {table_name};"

    cursor.execute(query)

    columns_info = cursor.fetchall()

    column_names = [column_info[0] for column_info in columns_info]

    column_names.pop(0)
    column_names.pop(len(column_names)-1)


    count = 1
    gruppe_ids = []
    for gr in column_names:
        print(f'Tast {count} for {gr}')
        gruppe_ids.append(count)
        count = count + 1
    
    bruger_valg = []
    exit = 999

    while exit == 999:
        vaelger = int(input(f'{grupper_prompt}'))
        if vaelger == 0:
            break
        if vaelger in bruger_valg:
            print(f'Du har allerede valgt {vaelger}')
        if vaelger not in gruppe_ids:
            print(f'{vaelger} findes ikke. Du må prøve igen.')
        elif vaelger not in bruger_valg:
            bruger_valg.append(vaelger)

    grupper = []
    if bruger_valg:
        if table_name == "grupper":
            for x in bruger_valg:
                grupper.append(column_names[x-1]+"_gruppe")
            return grupper
        elif table_name == "udstyr":
            for x in bruger_valg:
                grupper.append("udstyr_"+column_names[x-1])
            return grupper
    else:
        grupper = [""]
        return grupper

    cursor.close()
    mydb.close()